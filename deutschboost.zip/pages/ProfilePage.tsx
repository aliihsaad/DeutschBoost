import React from 'react';
import Card from '../components/Card';
import { CEFRLevel } from '../types';

interface ProfilePageProps {
  userLevel: CEFRLevel;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ userLevel }) => {
  return (
    <div className="container mx-auto p-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold">Profile & Settings</h1>
        <p className="text-gray-600 mt-2">Manage your account and learning preferences.</p>
      </header>
      <Card className="max-w-2xl mx-auto">
        <div className="flex items-center space-x-6">
          <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center text-4xl text-gray-500">
            <i className="fa-solid fa-user"></i>
          </div>
          <div>
            <h2 className="text-2xl font-bold">Learner_123</h2>
            <p className="text-gray-600">Joined: 2024</p>
            <p className="mt-2 text-lg font-semibold">Current Level: <span className="text-blue-600">{userLevel}</span></p>
          </div>
        </div>
        <hr className="my-6" />
        <div>
          <h3 className="text-xl font-bold mb-4">Settings</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
                <label htmlFor="notifications" className="font-semibold">Email Notifications</label>
                <div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
                    <input type="checkbox" name="notifications" id="notifications" className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"/>
                    <label htmlFor="notifications" className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"></label>
                </div>
            </div>
             <div className="flex justify-between items-center">
                <label htmlFor="darkMode" className="font-semibold">Dark Mode</label>
                 <div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
                    <input type="checkbox" name="darkMode" id="darkMode" className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"/>
                    <label htmlFor="darkMode" className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"></label>
                </div>
            </div>
          </div>
        </div>
        <style>{`
            .toggle-checkbox:checked { right: 0; border-color: #2563eb; }
            .toggle-checkbox:checked + .toggle-label { background-color: #2563eb; }
        `}</style>
      </Card>
    </div>
  );
};

export default ProfilePage;