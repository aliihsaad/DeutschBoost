import React from 'react';
import { Page } from '../types';

interface HeaderProps {
  currentPage: Page;
  setPage: (page: Page) => void;
}

const NavItem: React.FC<{
  page: Page;
  icon: string;
  currentPage: Page;
  setPage: (page: Page) => void;
  children: React.ReactNode;
}> = ({ page, icon, currentPage, setPage, children }) => (
  <button
    onClick={() => setPage(page)}
    className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors duration-200 ${
      currentPage === page
        ? 'bg-blue-600 text-white shadow-md'
        : 'text-gray-700 hover:bg-gray-200'
    }`}
  >
    <i className={`fa-solid ${icon}`}></i>
    <span>{children}</span>
  </button>
);

const Header: React.FC<HeaderProps> = ({ currentPage, setPage }) => {
  return (
    <header className="bg-white shadow-sm p-4 sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <img src="https://em-content.zobj.net/source/apple/354/flag-germany_1f1e9-1f1ea.png" alt="German Flag" className="h-8 w-8" />
          <h1 className="text-2xl font-bold text-blue-700">DeutschBoost</h1>
        </div>
        <nav className="flex items-center space-x-2">
          <NavItem page={Page.Home} icon="fa-house" currentPage={currentPage} setPage={setPage}>
            Home
          </NavItem>
          <NavItem page={Page.PlacementTest} icon="fa-clipboard-question" currentPage={currentPage} setPage={setPage}>
            Test
          </NavItem>
          <NavItem page={Page.LearningPlan} icon="fa-map-signs" currentPage={currentPage} setPage={setPage}>
            Plan
          </NavItem>
          <NavItem page={Page.Conversation} icon="fa-microphone-alt" currentPage={currentPage} setPage={setPage}>
            Sprechen
          </NavItem>
          <NavItem page={Page.Profile} icon="fa-user-gear" currentPage={currentPage} setPage={setPage}>
            Profile
          </NavItem>
        </nav>
      </div>
    </header>
  );
};

export default Header;