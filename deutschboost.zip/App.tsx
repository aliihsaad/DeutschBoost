
import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import PlacementTestPage from './pages/PlacementTestPage';
import LearningPlanPage from './pages/LearningPlanPage';
import ConversationPage from './pages/ConversationPage';
import ProfilePage from './pages/ProfilePage';
import { Page, CEFRLevel, TestResult, LearningPlan } from './types';
import { generateLearningPlan } from './services/geminiService';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(Page.Home);
  const [userLevel, setUserLevel] = useState<CEFRLevel>(CEFRLevel.A1);
  const [learningPlan, setLearningPlan] = useState<LearningPlan | null>(null);
  const [loadingPlan, setLoadingPlan] = useState(false);
  
  const handleTestComplete = useCallback(async (result: TestResult) => {
    setUserLevel(result.level);
    setCurrentPage(Page.LearningPlan);
    setLoadingPlan(true);
    try {
        const plan = await generateLearningPlan(result);
        setLearningPlan(plan);
    } catch(error) {
        console.error("Failed to generate learning plan", error);
        alert("We couldn't generate your learning plan. Please try taking the test again.");
        setCurrentPage(Page.Home); // Go back home on failure
    } finally {
        setLoadingPlan(false);
    }
  }, []);

  const handleTogglePlanItem = (weekIndex: number, itemIndex: number) => {
    setLearningPlan(prevPlan => {
        if (!prevPlan) return null;
        const newPlan = JSON.parse(JSON.stringify(prevPlan)); // Deep copy
        const item = newPlan.weeks[weekIndex].items[itemIndex];
        item.completed = !item.completed;
        return newPlan;
    });
  };

  const renderPage = () => {
    switch (currentPage) {
      case Page.Home:
        return <HomePage setPage={setCurrentPage} learningPlan={learningPlan} userLevel={userLevel}/>;
      case Page.PlacementTest:
        return <PlacementTestPage onTestComplete={handleTestComplete} />;
      case Page.LearningPlan:
        return <LearningPlanPage learningPlan={learningPlan} loading={loadingPlan} onToggleItem={handleTogglePlanItem}/>;
      case Page.Conversation:
        return <ConversationPage />;
      case Page.Profile:
        return <ProfilePage userLevel={userLevel} />;
      default:
        return <HomePage setPage={setCurrentPage} learningPlan={learningPlan} userLevel={userLevel}/>;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header currentPage={currentPage} setPage={setCurrentPage} />
      <main className="flex-grow">
        {renderPage()}
      </main>
      <footer className="bg-slate-800 text-white text-center p-4">
        <p>&copy; 2024 DeutschBoost. Learn German smarter with AI.</p>
      </footer>
    </div>
  );
};

export default App;
